"""학생 자율주차 알고리즘 (전면주차 / Front-in).

설계 방침
---------
1) 교수님 공지 반영:
   - 주차 방향은 자유 → 후진(rear-in) 모듈은 만들지 않고 전면주차로 통일.
   - 최종 평가는 '별도의 맵'에서 진행 → 특정 맵에 하드코딩하지 않고,
     맵 payload(extent, cellSize, slots, lines)와 obs(state, target_slot, limits)
     에서 받은 값만으로 동작하도록 일반화한다.

2) 채점(만점) 전략:
   - 성공 게이트(필수): 슬롯 IoU >= 0.30  &  |v| <= 0.2  &  방향 != unknown
   - parking_iou: IoU >= 0.65 면 만점 → 슬롯 중심·축에 정확히 정렬해 진입
   - parking_stop: 도착 시 완전 정지(v≈0)
   - speed:       접근 구간은 빠르게(평균속도 목표 충족), 슬롯 근처에서만 감속
   - steer_flip:  경로 스무딩(LOS) + 초반 직선화로 좌↔우 흔들림 최소화

알고리즘
---------
- set_map():        거리장(distance field) 기반 코스트맵 생성 (셀크기 일반화)
- compute_planning(): 타깃 슬롯/진입방향/게이트 → 3단계 Fail-Safe A* → 스무딩 → 슬롯 직선 진입
- compute_control(): Pure-Pursuit 추종 + 거리 기반 속도 스케줄 + 완전 정지
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import math
import heapq
import numpy as np


def normalize_angle(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


@dataclass
class PlannerSkeleton:
    # ---- 맵 / 격자 ----
    map_data: Optional[Dict[str, Any]] = None
    map_extent: Optional[Tuple[float, float, float, float]] = None  # (xmin,xmax,ymin,ymax)
    cell_size: float = 0.5
    grid_width: int = 0
    grid_height: int = 0

    # ---- 코스트맵 ----
    base_cost_map: Optional[np.ndarray] = None  # 맵 고정 코스트(거리장)
    cost_map: Optional[np.ndarray] = None       # 타깃별 사본(경로 카빙 반영)

    # ---- 장애물 / 슬롯 ----
    slots: List[Tuple[float, float, float, float]] = None
    lines: List[Tuple[float, float, float, float]] = None

    # ---- 경로 / 타깃 ----
    waypoints: List[Tuple[float, float]] = None
    target_center: Optional[Tuple[float, float]] = None
    target_entry_vec: Optional[Tuple[float, float]] = None  # 슬롯으로 '들어가는' 방향 단위벡터

    # ---- 안전 마진(미터) : 셀크기에 독립적으로 유지 ----
    safety_margin_m: float = 1.5   # 차폭/대각 고려한 여유(차량 반경 ~)

    # ---- 상태 플래그 ----
    planning_done: bool = False
    is_parked: bool = False

    def __post_init__(self) -> None:
        if self.waypoints is None:
            self.waypoints = []
        if self.slots is None:
            self.slots = []
        if self.lines is None:
            self.lines = []

    # ============================================================
    # 맵 수신 / 전처리
    # ============================================================
    def set_map(self, map_payload: Dict[str, Any]) -> None:
        self.map_data = map_payload
        self.map_extent = tuple(map(float, map_payload.get("extent", (0, 0, 0, 0))))
        self.cell_size = float(map_payload.get("cellSize", 0.5))

        self.slots = [tuple(map(float, s)) for s in (map_payload.get("slots") or [])]
        self.lines = [tuple(map(float, ln)) for ln in (map_payload.get("lines") or [])]

        # 세션 리셋
        self.waypoints.clear()
        self.planning_done = False
        self.is_parked = False
        self.target_center = None
        self.target_entry_vec = None

        self._precompute_base_map()

    def _to_grid(self, wx: float, wy: float) -> Tuple[int, int]:
        if not self.map_extent:
            return 0, 0
        xmin, _, ymin, _ = self.map_extent
        gx = int((wx - xmin) / self.cell_size)
        gy = int((wy - ymin) / self.cell_size)
        gx = max(0, min(self.grid_width - 1, gx))
        gy = max(0, min(self.grid_height - 1, gy))
        return gx, gy

    def _to_world(self, gx: int, gy: int) -> Tuple[float, float]:
        xmin, _, ymin, _ = self.map_extent
        return xmin + (gx + 0.5) * self.cell_size, ymin + (gy + 0.5) * self.cell_size

    def _precompute_base_map(self) -> None:
        """슬롯/라인/테두리를 장애물로 보고 거리장 → 코스트맵 생성.
        모든 픽셀 수치를 cell_size 기준으로 환산해 임의 맵에 일반화."""
        if not self.map_extent:
            return
        xmin, xmax, ymin, ymax = self.map_extent
        self.grid_width = int(np.ceil((xmax - xmin) / self.cell_size))
        self.grid_height = int(np.ceil((ymax - ymin) / self.cell_size))
        H, W = self.grid_height, self.grid_width

        base = np.zeros((H, W), dtype=np.float32)

        # (1) 슬롯 영역을 장애물로 마킹 (1셀 인플레이션)
        for s in self.slots:
            gx1, gy1 = self._to_grid(s[0], s[2])
            gx2, gy2 = self._to_grid(s[1], s[3])
            r0, r1 = max(0, min(gy1, gy2) - 1), min(H, max(gy1, gy2) + 1)
            c0, c1 = max(0, min(gx1, gx2) - 1), min(W, max(gx1, gx2) + 1)
            base[r0:r1, c0:c1] = 1.0

        # (2) 라인 세그먼트를 장애물로 마킹
        sample_step = self.cell_size * 0.5
        for (x1, y1, x2, y2) in self.lines:
            dist = math.hypot(x2 - x1, y2 - y1)
            steps = int(dist / sample_step) + 1
            for k in range(steps):
                t = k / steps
                gx, gy = self._to_grid(x1 + t * (x2 - x1), y1 + t * (y2 - y1))
                base[gy, gx] = 1.0

        # (3) 맵 테두리 = 벽
        base[0, :] = base[-1, :] = 1.0
        base[:, 0] = base[:, -1] = 1.0

        # (4) 8방향 다익스트라 거리장 (셀 단위 거리)
        INF = np.inf
        dist_map = np.full((H, W), INF, dtype=np.float32)
        pq: List[Tuple[float, int, int]] = []
        oy, ox = np.where(base > 0.5)
        for y, x in zip(oy, ox):
            dist_map[y, x] = 0.0
            heapq.heappush(pq, (0.0, x, y))

        dirs = [(1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
                (1, 1, 1.414), (1, -1, 1.414), (-1, 1, 1.414), (-1, -1, 1.414)]

        # 거리장은 (안전마진 + 1.5m)까지만 전파.
        #  이보다 먼 셀은 inf로 남겨 저코스트(0.05)가 되게 → 차로 중앙에 넓은 주행 회랑 형성.
        #  cell_size로 환산하므로 임의 맵에 일반화됨.
        max_field_cells = (self.safety_margin_m + 1.5) / self.cell_size
        while pq:
            d, cx, cy = heapq.heappop(pq)
            if d > dist_map[cy, cx] or d > max_field_cells:
                continue
            for dx, dy, w in dirs:
                nx, ny = cx + dx, cy + dy
                if 0 <= nx < W and 0 <= ny < H:
                    nd = d + w
                    if nd < dist_map[ny, nx]:
                        dist_map[ny, nx] = nd
                        heapq.heappush(pq, (nd, nx, ny))

        # (5) 거리장 → 코스트맵 [0.05, 1.0]
        #     장애물에서 차량반경(셀) 이내는 고비용(1.0), 멀어질수록 저비용
        veh_radius_px = self.safety_margin_m / self.cell_size
        falloff = max(1.0, 20.0)  # 멀어질수록 완만히 감소
        cost = np.ones((H, W), dtype=np.float32)
        safe = dist_map > veh_radius_px
        cost[safe] = np.clip(1.0 - (dist_map[safe] - veh_radius_px) / falloff, 0.05, 0.9)
        self.base_cost_map = cost

    # ============================================================
    # 타깃 코스트맵 준비 (슬롯 앞 진입로 카빙)
    # ============================================================
    def _prepare_cost_map_for_target(self, target_idx: int) -> None:
        if self.base_cost_map is None:
            self._precompute_base_map()
        self.cost_map = self.base_cost_map.copy()
        if target_idx != -1:
            self._carve_target_path(target_idx)

    def _carve_target_path(self, target_idx: int) -> None:
        sx1, sx2, sy1, sy2 = self.slots[target_idx]
        cx, cy = (sx1 + sx2) / 2.0, (sy1 + sy2) / 2.0
        dx, dy = self.target_entry_vec
        carve_dist = 6.0  # 슬롯 앞 정렬 공간(m)
        steps = int(carve_dist / (self.cell_size * 0.5))
        cw = 2  # 카빙 반폭(셀)
        for s in range(steps):
            d = s * (self.cell_size * 0.5)
            gx, gy = self._to_grid(cx + dx * d, cy + dy * d)
            for py in range(-cw, cw + 1):
                for px in range(-cw, cw + 1):
                    nx, ny = gx + px, gy + py
                    if 0 <= nx < self.grid_width and 0 <= ny < self.grid_height:
                        self.cost_map[ny, nx] = 0.01

    def _is_behind_target(self, nx: int, ny: int) -> bool:
        """슬롯 '뒤쪽'(진입 반대편) 영역인지 — Constraint 단계에서 탐색 금지."""
        if self.target_center is None or self.target_entry_vec is None:
            return False
        wx, wy = self._to_world(nx, ny)
        tcx, tcy = self.target_center
        dx, dy = self.target_entry_vec
        bx, by = tcx + dx * 2.0, tcy + dy * 2.0
        return (wx - bx) * dx + (wy - by) * dy > 0

    # ============================================================
    # A* (3단계 Fail-Safe) + 스무딩
    # ============================================================
    def generate_path_astar(self, start_pos, target_pos,
                            use_constraint=True, max_cost=0.6):
        start = self._to_grid(*start_pos)
        goal = self._to_grid(*target_pos)

        if self.cost_map[goal[1], goal[0]] > 0.95:
            return []
        # 출발 지점과 그 주변(2셀)을 완화 → 시작이 장애물에 둘러싸여 있어도 탈출 가능
        for py in range(-2, 3):
            for px in range(-2, 3):
                nx, ny = start[0] + px, start[1] + py
                if 0 <= nx < self.grid_width and 0 <= ny < self.grid_height:
                    if self.cost_map[ny, nx] > max_cost:
                        self.cost_map[ny, nx] = min(self.cost_map[ny, nx], 0.3)

        open_set = [(0.0, 0.0, start)]
        came: Dict[Tuple[int, int], Tuple[int, int]] = {}
        g_score = {start: 0.0}
        dirs = [(0, 1), (0, -1), (1, 0), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1)]

        # 반복 한계도 맵 크기에 비례하게(큰 맵 일반화), 단 과도하지 않게 캡
        max_iter = int(min(max(6000, self.grid_width * self.grid_height), 120000))
        final_node = None
        best_dist, best_node = float("inf"), start
        it = 0

        while open_set:
            it += 1
            if it > max_iter:
                final_node = best_node
                break
            _, _, cur = heapq.heappop(open_set)
            dg = math.hypot(cur[0] - goal[0], cur[1] - goal[1])
            if dg < best_dist:
                best_dist, best_node = dg, cur
            if dg < 2.0:
                final_node = cur
                break
            for dx, dy in dirs:
                nx, ny = cur[0] + dx, cur[1] + dy
                if not (0 <= nx < self.grid_width and 0 <= ny < self.grid_height):
                    continue
                if self.cost_map[ny, nx] > max_cost:
                    continue
                if use_constraint and self._is_behind_target(nx, ny):
                    continue
                move = math.hypot(dx, dy) + self.cost_map[ny, nx] * 10.0
                ng = g_score[cur] + move
                if (nx, ny) not in g_score or ng < g_score[(nx, ny)]:
                    g_score[(nx, ny)] = ng
                    h = math.hypot(nx - goal[0], ny - goal[1]) * 1.5  # weighted A*
                    heapq.heappush(open_set, (ng + h, ng, (nx, ny)))
                    came[(nx, ny)] = cur

        if not final_node:
            return []

        path = []
        cur = final_node
        while cur in came:
            path.append(self._to_world(*cur))
            cur = came[cur]
        path.append(self._to_world(*start))
        path.reverse()
        return self._smooth_path(path)

    def _smooth_path(self, raw):
        """계단형 A* → 촘촘히 샘플 후 LOS로 직선화."""
        if len(raw) < 3:
            return raw
        dense = []
        for i in range(len(raw) - 1):
            p1, p2 = raw[i], raw[i + 1]
            d = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
            n = int(d / (self.cell_size)) + 1
            for j in range(n):
                a = j / n
                dense.append((p1[0] + a * (p2[0] - p1[0]), p1[1] + a * (p2[1] - p1[1])))
        dense.append(raw[-1])

        out = [dense[0]]
        i = 1
        max_shortcut_m = 5.0  # 너무 긴 shortcut은 코너를 미리 잘라먹어서 라인 충돌을 유발함
        while i < len(dense):
            shortcut_len = math.hypot(dense[i][0] - out[-1][0], dense[i][1] - out[-1][1])
            if shortcut_len > max_shortcut_m or not self._line_of_sight(out[-1], dense[i]):
                out.append(dense[i - 1])
            if i == len(dense) - 1:
                out.append(dense[i])
            i += 1
        return out

    def _line_of_sight(self, p1, p2, threshold=0.7):
        c1, r1 = self._to_grid(p1[0], p1[1])
        c2, r2 = self._to_grid(p2[0], p2[1])
        dr, dc = abs(r2 - r1), abs(c2 - c1)
        sr = 1 if r1 < r2 else -1
        sc = 1 if c1 < c2 else -1
        err = dr - dc
        r, c = r1, c1
        while True:
            if not (0 <= r < self.grid_height and 0 <= c < self.grid_width):
                return False
            if self.cost_map[r, c] > threshold:
                return False
            if r == r2 and c == c2:
                return True
            e2 = 2 * err
            if e2 > -dc:
                err -= dc
                r += sr
            if e2 < dr:
                err += dr
                c += sc

    # ============================================================
    # 메인 플래닝 (1회 실행)
    # ============================================================
    def compute_planning(self, obs: Dict[str, Any]) -> None:
        state = obs.get("state", {})
        sx, sy = float(state.get("x", 0)), float(state.get("y", 0))
        target = obs.get("target_slot")
        if not target:
            return

        t_cx = (target[0] + target[1]) / 2.0
        t_cy = (target[2] + target[3]) / 2.0
        w, h = target[1] - target[0], target[3] - target[2]

        map_cx = (self.map_extent[0] + self.map_extent[1]) / 2.0
        map_cy = (self.map_extent[2] + self.map_extent[3]) / 2.0

        # 진입 방향: 슬롯이 차로(맵 중앙) 쪽으로 열려 있다고 가정.
        #  - 세로 슬롯(h>w): 위/아래(±y)로 진입
        #  - 가로 슬롯       : 좌/우(±x)로 진입
        # 전면주차이므로 '맵 중앙을 향해 노즈가 들어가는' 방향을 entry_vec로.
        dx, dy = 0.0, 0.0
        if h >= w:
            dy = -1.0 if t_cy > map_cy else 1.0
        else:
            dx = -1.0 if t_cx > map_cx else 1.0
        self.target_center = (t_cx, t_cy)
        self.target_entry_vec = (dx, dy)

        # target_slot과 가장 가까운 슬롯 인덱스 (코스트맵 카빙용)
        best_idx, min_d = -1, float("inf")
        for i, s in enumerate(self.slots):
            cx, cy = (s[0] + s[1]) / 2.0, (s[2] + s[3]) / 2.0
            d = (t_cx - cx) ** 2 + (t_cy - cy) ** 2
            if d < min_d:
                min_d, best_idx = d, i
        self._prepare_cost_map_for_target(best_idx)

        # 게이트: 슬롯 중심에서 진입방향으로 나가며 저비용 지점 탐색
        gate = (t_cx, t_cy)
        gd = 5.0
        while gd >= 1.5:
            gx, gy = t_cx + dx * gd, t_cy + dy * gd
            ggx, ggy = self._to_grid(gx, gy)
            if 0 <= ggx < self.grid_width and 0 <= ggy < self.grid_height:
                if self.cost_map[ggy, ggx] < 0.6:
                    gate = (gx, gy)
                    break
            gd -= 0.5
        gx, gy = gate

        # 3단계 Fail-Safe A* : Constraint → Standard → Relaxed → (안전망) 초완화
        path = self.generate_path_astar((sx, sy), (gx, gy), use_constraint=True, max_cost=0.6)
        if not path:
            path = self.generate_path_astar((sx, sy), (gx, gy), use_constraint=False, max_cost=0.6)
        if not path:
            path = self.generate_path_astar((sx, sy), (gx, gy), use_constraint=False, max_cost=0.85)
        if not path:
            # 좁은 통로뿐인 맵 대비: 장애물 직전(0.95)까지 허용
            path = self.generate_path_astar((sx, sy), (gx, gy), use_constraint=False, max_cost=0.95)
        if not path:
            return  # 다음 틱에 재시도

        # 출발 직후 직선화 (초반 좌우 흔들림 ↓ → steer_flip 점수 ↑)
        cut_idx = -1
        for i, p in enumerate(path):
            if math.hypot(p[0] - sx, p[1] - sy) > 3.5:
                cut_idx = i
                break
        if cut_idx != -1 and self._line_of_sight((sx, sy), path[cut_idx]):
            cp = path[cut_idx]
            straight = [(sx + (i / 10) * (cp[0] - sx), sy + (i / 10) * (cp[1] - sy))
                        for i in range(10)]
            path = straight + path[cut_idx:]

        # 게이트 → 슬롯 중심 직선 진입 (차량 자세를 슬롯 축과 평행 정렬 → IoU/방향 ↑)
        final_seg = []
        steps = 15
        for i in range(1, steps + 1):
            t = i / steps
            final_seg.append((gx + t * (t_cx - gx), gy + t * (t_cy - gy)))

        self.waypoints = path + final_seg
        self.planning_done = True

    # ============================================================
    # Pure-Pursuit 추종 + 속도 스케줄
    # ============================================================
    def _lookahead_point(self, x, y, v, dist_goal=None):
        Ld = max(2.0, min(2.0 + 0.7 * v, 7.0))
        # 목표 근처에서는 lookahead를 줄여 슬롯 축에 정밀 정렬(짧은 경로 빙빙 도는 것 방지)
        if dist_goal is not None:
            Ld = min(Ld, max(1.2, dist_goal * 0.6))
        # 가장 가까운 웨이포인트
        ci, md = 0, float("inf")
        for i, (wx, wy) in enumerate(self.waypoints):
            d = math.hypot(wx - x, wy - y)
            if d < md:
                md, ci = d, i
        # 그 이후 Ld 이상 떨어진 점
        for i in range(ci, len(self.waypoints)):
            wx, wy = self.waypoints[i]
            if math.hypot(wx - x, wy - y) >= Ld:
                return self.waypoints[i]
        return self.waypoints[-1]

    def compute_control(self, obs: Dict[str, Any]) -> Dict[str, float]:
        t = float(obs.get("t", 0.0))
        st = obs.get("state", {})
        x, y = float(st.get("x", 0)), float(st.get("y", 0))
        yaw, v = float(st.get("yaw", 0)), float(st.get("v", 0))
        limits = obs.get("limits", {})
        L = float(limits.get("L", 2.6))
        max_steer = float(limits.get("maxSteer", math.radians(35)))

        if self.is_parked:
            return {"steer": 0.0, "accel": 0.0, "brake": 1.0, "gear": "D"}

        # 초반: 정지 상태에서 1회 플래닝
        if t < 1.0 or not self.planning_done:
            if not self.planning_done and t > 0.2:
                self.compute_planning(obs)
            return {"steer": 0.0, "accel": 0.0, "brake": 1.0, "gear": "D"}

        if not self.waypoints:
            return {"steer": 0.0, "accel": 0.0, "brake": 1.0, "gear": "D"}

        # --- 조향 (Pure-Pursuit) ---
        gx, gy = self.waypoints[-1]
        dist_goal = math.hypot(gx - x, gy - y)
        tx, ty = self._lookahead_point(x, y, v, dist_goal)
        alpha = normalize_angle(math.atan2(ty - y, tx - x) - yaw)
        Lf = max(0.1, math.hypot(tx - x, ty - y))
        steer = math.atan2(2.0 * L * math.sin(alpha), Lf)
        steer = max(-max_steer, min(max_steer, steer))  # limits 준수

        # --- 속도 스케줄 ---

        # 멀리서는 빠르게(평균속도 점수) → 슬롯 근처에서만 감속
        if dist_goal > 8.0:
            target_v = 6.0
        elif dist_goal > 3.0:
            target_v = 1.8
        elif dist_goal > 0.3:
            target_v = 0.8
        else:
            target_v = 0.0

        err = target_v - v
        accel = brake = 0.0
        if target_v == 0.0:
            brake = 1.0
        elif v < target_v:
            accel = min(0.6, max(0.0, err * 0.4))
        elif v > target_v + 0.5:
            brake = min(0.4, (-err) * 0.3)
        # (target_v ≤ v ≤ target_v+0.5) 구간은 coast

        # 도착: 완전 정지 → 성공 게이트(|v|≤0.2) & parking_stop 만점
        if dist_goal < 0.25:
            self.is_parked = True
            return {"steer": steer, "accel": 0.0, "brake": 1.0, "gear": "D"}

        return {"steer": steer, "accel": accel, "brake": brake, "gear": "D"}


# ---- 통신 모듈이 사용하는 전역 인터페이스 (이름 유지 필수) ----
planner = PlannerSkeleton()


def handle_map_payload(map_payload: Dict[str, Any]) -> None:
    planner.set_map(map_payload)


def planner_step(obs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return planner.compute_control(obs)
    except Exception as exc:  # 예외 시 안전 정지
        print(f"[algo] planner_step error: {exc}")
        return {"steer": 0.0, "accel": 0.0, "brake": 0.5, "gear": "D"}